<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_groupassign';
$plugin->version = 2026061501;
$plugin->requires = 2024100700;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.1.6';
