<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Groupassign for mod_groupassign.
 *
 * @package    mod_groupassign
 * @copyright  2026 Matthew Darch <matthew.darch.1up@gmail.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['modulename'] = 'Group assignment';
$string['modulename_help'] = 'Use a group assignment to form student groups, collect group work, and support peer/self evaluation in one activity.';
$string['modulenameplural'] = 'Group assignments';
$string['pluginadministration'] = 'Group assignment administration';
$string['pluginname'] = 'Group assignment';
$string['groupassign:addinstance'] = 'Add a new group assignment';
$string['groupassign:grade'] = 'Grade group assignments';
$string['groupassign:join'] = 'Join or leave group assignment groups';
$string['groupassign:managegroups'] = 'Manage group assignment groups';
$string['allgroupsready'] = 'All groups are within the configured size range.';
$string['allowstudentcreate'] = 'Allow students to create groups';
$string['allowstudentdescription'] = 'Allow students to edit group descriptions';
$string['allowstudentjoin'] = 'Allow students to join groups';
$string['allowstudentleave'] = 'Allow students to leave groups';
$string['allowstudentrename'] = 'Allow students to name new groups';
$string['availability'] = 'Availability';
$string['calendareventcutoff'] = 'Cut-off date';
$string['calendareventdue'] = 'Due date';
$string['calendareventgradingdue'] = 'Remind me to grade by';
$string['choosegroup'] = 'Choose your group';
$string['creategroup'] = 'Create group';
$string['currentgroup'] = 'Your group';
$string['coursecopycheck'] = 'Course copy check';
$string['coursecopywarningmissinggrouping'] = 'This activity is set to use an existing grouping, but the grouping is missing. This can happen after course copy/import if groups and groupings were not copied.';
$string['coursecopywarningnogroups'] = 'No groups are available for this activity yet. Review the group formation settings before students begin.';
$string['coursecopywarningunallocated'] = '{$a} enrolled student(s) are not in an activity group yet.';
$string['dashboardoverview'] = 'Dashboard overview';
$string['duedate'] = 'Due date';
$string['emptygroups'] = 'Empty groups';
$string['eventgroupcreated'] = 'Group created';
$string['eventgroupjoined'] = 'Group joined';
$string['eventgroupleft'] = 'Group left';
$string['eventpeerreviewsaved'] = 'Peer review saved';
$string['eventsubmissiongraded'] = 'Submission graded';
$string['eventsubmissionsaved'] = 'Submission saved';
$string['feedback'] = 'Feedback';
$string['formation:auto'] = 'Create groups for teacher allocation';
$string['formation:existing'] = 'Use an existing grouping';
$string['formation:selfselect'] = 'Student self-selection';
$string['formationmode'] = 'Group formation';
$string['formationmode_help'] = 'Choose whether this activity should create and manage groups, let students self-select, or use an existing Moodle grouping.';
$string['grade'] = 'Grade';
$string['gradedby'] = 'Graded by';
$string['gradedgroups'] = 'Graded groups';
$string['gradeoutofrange'] = 'Grade must be between 0 and {$a}.';
$string['gradesaved'] = 'Grade saved and sent to the Gradebook.';
$string['gradeitem:submissions'] = 'Group assignment';
$string['gradingduedate'] = 'Remind me to grade by';
$string['groupcreated'] = 'Group created.';
$string['groupdescription'] = 'Group description';
$string['groupformation'] = 'Group formation';
$string['groupfull'] = 'Full';
$string['groupingmanaged'] = 'Managed by this activity';
$string['groupingused'] = 'Grouping used';
$string['groupjoined'] = 'You have joined the group.';
$string['groupleft'] = 'You have left the group.';
$string['groupmembershiplocked'] = 'Group membership is locked because this group has already submitted work.';
$string['groupmanagementsummary'] = 'Group management summary';
$string['groupname'] = 'Group name';
$string['groupnameprefix'] = 'Group name prefix';
$string['groupnameprefix_help'] = 'The text used before each generated group suffix. Leave blank to use the assignment activity name.';
$string['groupnamesuffix'] = 'Group name suffix';
$string['groupnamesuffix:letters'] = 'Letters: A, B, C';
$string['groupnamesuffix:numbers'] = 'Numbers: 1, 2, 3';
$string['groupsetup'] = 'Group setup';
$string['groupsandmembership'] = 'Groups and membership';
$string['gradeisnone'] = 'This activity is set to No grade. Feedback can still be saved, but no numeric or scale grade will be sent to the gradebook.';
$string['hidefullgroups'] = 'Hide full groups from students';
$string['hidefullgroups_help'] = 'When enabled, students only see groups that still have space, plus their current group.';
$string['individualadjustments'] = 'Individual adjustments';
$string['individualadjustments_help'] = 'Leave these blank to apply the group grade and feedback to every member. Add a member-specific grade and feedback only when you need to adjust an individual result.';
$string['individualfeedbackfor'] = 'Individual feedback for {$a}';
$string['individualfeedbackrequired'] = 'Add feedback explaining the individual grade adjustment.';
$string['individualgradefor'] = 'Individual grade for {$a}';
$string['invalidgrade'] = 'Select a valid grade.';
$string['invalidgroupid'] = 'Invalid group.';
$string['join'] = 'Join';
$string['late'] = 'Late';
$string['latesubmissions'] = 'Late submissions';
$string['leave'] = 'Leave';
$string['maxmembers'] = 'Maximum members per group';
$string['members'] = 'Members';
$string['minmembers'] = 'Minimum members per group';
$string['minmembers_error_bigger_maxmembers'] = 'Minimum members cannot be greater than maximum members.';
$string['needsgrading'] = 'Needs grading';
$string['nogroup'] = 'You are not in a group yet.';
$string['nogroups'] = 'No groups are available yet.';
$string['notsubmitted'] = 'Not submitted';
$string['numgroups'] = 'Number of blank groups to create';
$string['overfullgroups'] = 'Overfull groups';
$string['peerassessment'] = 'Peer assessment';
$string['peerassessment_help'] = 'Peer assessment collects evidence about group contribution. It does not automatically recalculate grades.';
$string['peercomments'] = 'Allow comments';
$string['peercomments_help'] = 'When enabled, students can include written comments with each peer rating.';
$string['peercriteria_description'] = 'Criterion description';
$string['peercriteria_ratingtype'] = 'Scoring type';
$string['peerrequirejustification'] = 'Require justification for ratings';
$string['peerrequirejustification_help'] = 'When enabled, students must provide a comment for each peer rating.';
$string['peercomment'] = 'Comment';
$string['peercriteria'] = 'Peer assessment criteria';
$string['peercriteria_help'] = 'Use short criteria students can apply to each group member. Empty criteria are ignored.';
$string['peercriterion1'] = 'Contribution to group tasks';
$string['peercriterion2'] = 'Communication and responsiveness';
$string['peercriterion3'] = 'Reliability and meeting agreed deadlines';
$string['peercriterion4'] = 'Collaboration and support for others';
$string['peercriterion5'] = 'Quality of individual input';
$string['peerenabled'] = 'Enable peer assessment';
$string['peerreview'] = 'Peer review';
$string['peerreviews'] = 'Peer reviews';
$string['peerreviewdisabled'] = 'Peer review is not enabled for this activity.';
$string['peerreviewsaved'] = 'Peer review saved.';
$string['peerreviewstatus:complete'] = 'Peer review complete';
$string['peerreviewstatus:notstarted'] = 'Peer review not started';
$string['peerreviewstatus:partial'] = 'Peer review in progress';
$string['peerrating:concern'] = 'Concern';
$string['peerrating:developing'] = 'Developing';
$string['peerrating:met'] = 'Met expectations';
$string['peerrating:exceeded'] = 'Exceeded expectations';
$string['peerrating:satisfactory'] = 'Satisfactory';
$string['peerrating:strong'] = 'Strong';
$string['peerrating:unsatisfactory'] = 'Unsatisfactory';
$string['peerratingtype:fourlevel'] = 'Four-level contribution scale';
$string['peerratingtype:marks5'] = 'Marks out of 5';
$string['peerratingtype:satisfactory'] = 'Satisfactory scale';
$string['peerselfassessment'] = 'Include self-assessment';
$string['savepeerreview'] = 'Save peer review';
$string['privacy:metadata:comment'] = 'The peer review comment.';
$string['privacy:metadata:core_files'] = 'Files attached to group submissions are stored using Moodle files.';
$string['privacy:metadata:criteriaid'] = 'The peer assessment criterion.';
$string['privacy:metadata:feedback'] = 'The grade feedback.';
$string['privacy:metadata:grade'] = 'The grade awarded.';
$string['privacy:metadata:graderid'] = 'The user who graded the work.';
$string['privacy:metadata:groupassign_groups'] = 'Tracks which Moodle groups are used by each group assignment.';
$string['privacy:metadata:groupassign_groups:groupassignid'] = 'The group assignment instance.';
$string['privacy:metadata:groupassign_groups:groupid'] = 'The Moodle group used by the activity.';
$string['privacy:metadata:groupassign_grades'] = 'Stores group grades and feedback.';
$string['privacy:metadata:groupassign_membergrades'] = 'Stores individual grade adjustments for group members.';
$string['privacy:metadata:groupassign_peerreviews'] = 'Stores peer review ratings and comments.';
$string['privacy:metadata:groupassign_submissions'] = 'Stores group submissions.';
$string['privacy:metadata:groupassignid'] = 'The group assignment instance.';
$string['privacy:metadata:groupid'] = 'The Moodle group.';
$string['privacy:metadata:rating'] = 'The peer review rating.';
$string['privacy:metadata:revieweeid'] = 'The user being reviewed.';
$string['privacy:metadata:reviewerid'] = 'The user providing the review.';
$string['privacy:metadata:status'] = 'The submission status.';
$string['privacy:metadata:submissiontext'] = 'The online text submitted by the group.';
$string['privacy:metadata:timecreated'] = 'The time this record was created.';
$string['privacy:metadata:timemodified'] = 'The time this record was last modified.';
$string['privacy:metadata:timesubmitted'] = 'The time the submission was made.';
$string['privacy:metadata:userid'] = 'The user associated with this record.';
$string['selectionclose'] = 'Selection closes';
$string['selectionclosed'] = 'Group selection is closed.';
$string['selectioncloses'] = 'Selection closes: {$a}';
$string['selectionisopen'] = 'Group selection is open.';
$string['selectionnotopen'] = 'Group selection is not open yet.';
$string['selectionopens'] = 'Selection opens: {$a}';
$string['selectionopen'] = 'Selection opens';
$string['selectionwindow'] = 'Selection window';
$string['resetgroupassignmemberships'] = 'Clear memberships from tracked group assignment groups';
$string['resetgroupassignsubmissions'] = 'Delete group assignment submissions, grades, feedback, and peer reviews';
$string['showmembers'] = 'Show group members to students';
$string['showmembers_help'] = 'When enabled, students can see who has already joined each group before choosing.';
$string['spotsavailable'] = '{$a} places available';
$string['status'] = 'Status';
$string['studentgroups'] = 'Student groups';
$string['studentswithoutgroup'] = 'Students without a group';
$string['switchgroup'] = 'Switch group';
$string['submission'] = 'Submission';
$string['submissionfiles'] = 'Submission files';
$string['submissioncomments'] = 'Submission comments';
$string['submissionfiletypes'] = 'Accepted file types';
$string['submissionfiletypes_help'] = 'Enter a comma-separated list of extensions such as .pdf,.docx,.pptx. Leave blank to allow all types.';
$string['submissions'] = 'Submissions';
$string['submissionsandgrading'] = 'Submissions and grading';
$string['submissionsaved'] = 'Group submission saved.';
$string['submissionsclosed'] = 'Submissions are not currently open for this activity.';
$string['submissionstatus:draft'] = 'Draft';
$string['submissionstatus:submitted'] = 'Submitted';
$string['submissiontext'] = 'Submission text';
$string['submissiontyperequired'] = 'Enable online text, file submissions, or both.';
$string['activityinstructions'] = 'Activity instructions';
$string['additionalfiles'] = 'Additional files';
$string['feedbacktypes'] = 'Feedback types';
$string['notifications'] = 'Notifications';
$string['feedbackcomments'] = 'Feedback comments';
$string['feedbackcommentsalwayson'] = 'Teachers can provide group feedback and individual adjustment feedback when grading.';
$string['notificationsdeferred'] = 'Notification controls are not enabled in this prototype yet. Submission, grading, and peer assessment events will be wired before a pilot.';
$string['quickgrading'] = 'Quick grading';
$string['searchusers'] = 'Search users';
$string['filterbyname'] = 'Filter by name';
$string['advancedfilter'] = 'Advanced';
$string['actions'] = 'Actions';
$string['gradebutton'] = 'Grade';
$string['grantsubmissionextension'] = 'Grant extension';
$string['editsubmission'] = 'Edit submission';
$string['nudge'] = 'Nudge';
$string['peerflag'] = 'Peer flag';
$string['peerflag:clear'] = 'Clear';
$string['peerflag:followup'] = 'Follow up';
$string['peerflag:concern'] = 'Potential concern';
$string['submittedgroups'] = 'Submitted groups';
$string['timedue_error_pre_timeavailable'] = 'The close date must be after the open date.';
$string['underfilledgroups'] = 'Underfilled groups';

// Strings previously borrowed from mod_assign and its subplugins.
$string['activityinstructions_help'] = 'The actions you would like the student to complete for this assignment. This is only shown on the submission page where a student edits and submits their assignment.';
$string['additionalfiles_help'] = 'Additional files for use in the assignment, such as answer templates, may be added.';
$string['allowsubmissionsfromdate'] = 'Allow submissions from';
$string['allowsubmissionsfromdate_help'] = 'If enabled, students will not be able to submit before this date. If disabled, students will be able to start submitting right away.';
$string['assignmentname'] = 'Assignment name';
$string['cutoffdate'] = 'Cut-off date';
$string['cutoffdate_help'] = 'If set, submissions will not be accepted after this date without an extension. If not set, submissions will always be accepted.';
$string['cutoffdatefromdatevalidation'] = 'Cut-off date cannot be earlier than the allow submissions from date.';
$string['cutoffdatevalidation'] = 'Cut-off date cannot be earlier than the due date.';
$string['description'] = 'Description';
$string['duedate_help'] = 'This is when the assignment is due. Submissions will still be allowed after this date, but any assignments submitted after this date will be marked as late. Set an assignment cut-off date to prevent submissions after a certain date.';
$string['duedateaftersubmissionvalidation'] = 'Due date must be after the allow submissions from date.';
$string['filesubmissions'] = 'File submissions';
$string['gradingduedate_help'] = 'The expected date that marking of the submissions should be completed by. This date is used to prioritise dashboard notifications for teachers.';
$string['gradingdueduedatevalidation'] = 'Remind me to grade by date cannot be earlier than the due date.';
$string['gradingduefromdatevalidation'] = 'Remind me to grade by date cannot be earlier than the allow submissions from date.';
$string['gradingsummary'] = 'Grading summary';
$string['maxfiles'] = 'Maximum files per submission';
$string['maximumsubmissionsize'] = 'Maximum submission size';
$string['onlinetext'] = 'Online text';
$string['requiresubmissionstatement'] = 'Require that students accept the submission statement';
$string['requiresubmissionstatement_help'] = 'Require that students accept the submission statement for all submissions to this assignment.';
$string['submissionsettings'] = 'Submission settings';
$string['submissiontypes'] = 'Submission types';
$string['timemodified'] = 'Last modified';
$string['wordlimit'] = 'Word limit';
$string['wordlimit_help'] = 'If online text submissions are enabled, this is the maximum number of words that each student will be allowed to submit.';
$string['submissionstatementteamsubmission'] = 'Group submission statement';
$string['submissionstatementteamsubmissiondefault'] = 'This submission is the work of my group, except where we have acknowledged the use of the works of other people.';
$string['submissionstatementrequired'] = 'You are required to agree to this statement before you can submit.';
$string['submitassignment'] = 'Submit assignment';
$string['wordlimitexceeded'] = 'The word limit for this assignment is {$a->limit} words and you are attempting to submit {$a->count} words. Please review your submission and try again.';
